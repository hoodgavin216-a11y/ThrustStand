#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2c.h"

// Pin & I2C Configuration matching your Wokwi diagram
#define I2C_MASTER_SCL_IO           22          // D22
#define I2C_MASTER_SDA_IO           21          // D21
#define I2C_MASTER_NUM              I2C_NUM_0   // I2C port 0
#define I2C_MASTER_FREQ_HZ          400000      // 400kHz Fast Mode
#define I2C_MASTER_TX_BUF_DISABLE   0
#define I2C_MASTER_RX_BUF_DISABLE   0

// MPU-6050 Registers
#define MPU6050_ADDR                0x68        // Default I2C address (AD0 = LOW)
#define MPU6050_PWR_MGMT_1          0x6B        // Power management register
#define MPU6050_ACCEL_XOUT_H        0x3B        // Start of 14-byte sensor data block

// Initialize ESP32 I2C Master
static esp_err_t i2c_master_init(void) {
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_MASTER_SDA_IO,
        .scl_io_num = I2C_MASTER_SCL_IO,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ,
    };
    i2c_param_config(I2C_MASTER_NUM, &conf);
    return i2c_driver_install(I2C_MASTER_NUM, conf.mode, I2C_MASTER_RX_BUF_DISABLE, I2C_MASTER_TX_BUF_DISABLE, 0);
}

// Write 1 byte to an MPU-6050 register
static esp_err_t mpu6050_write_byte(uint8_t reg_addr, uint8_t data) {
    uint8_t write_buf[2] = {reg_addr, data};
    return i2c_master_write_to_device(I2C_MASTER_NUM, MPU6050_ADDR, write_buf, sizeof(write_buf), pdMS_TO_TICKS(100));
}

// Read multiple bytes starting from a register
static esp_err_t mpu6050_read_bytes(uint8_t reg_addr, uint8_t *data, size_t len) {
    return i2c_master_write_read_device(I2C_MASTER_NUM, MPU6050_ADDR, &reg_addr, 1, data, len, pdMS_TO_TICKS(100));
}

void app_main(void) {
    ESP_ERROR_CHECK(i2c_master_init());
    printf("I2C initialized successfully.\n");

    // Wake up the MPU-6050 by writing 0x00 to PWR_MGMT_1
    esp_err_t ret = mpu6050_write_byte(MPU6050_PWR_MGMT_1, 0x00);
    if (ret != ESP_OK) {
        printf("MPU-6050 not detected! Check SDA/SCL wiring.\n");
        return;
    }
    printf("MPU-6050 woken up and ready!\n");

    uint8_t raw_data[14];

    while (true) {
        // Burst-read all 14 data bytes (Accel X/Y/Z, Temp, Gyro X/Y/Z)
        if (mpu6050_read_bytes(MPU6050_ACCEL_XOUT_H, raw_data, 14) == ESP_OK) {
            // Combine high and low bytes into signed 16-bit integers
            int16_t accel_x = (raw_data[0] << 8) | raw_data[1];
            int16_t accel_y = (raw_data[2] << 8) | raw_data[3];
            int16_t accel_z = (raw_data[4] << 8) | raw_data[5];
            int16_t gyro_x  = (raw_data[8] << 8) | raw_data[9];
            int16_t gyro_y  = (raw_data[10] << 8) | raw_data[11];
            int16_t gyro_z  = (raw_data[12] << 8) | raw_data[13];

            // Convert to physical units using default sensitivity (±2g -> 16384 LSB/g, ±250°/s -> 131 LSB/°/s)
            float ax_g = accel_x / 16384.0f;
            float ay_g = accel_y / 16384.0f;
            float az_g = accel_z / 16384.0f;

            float gx_dps = gyro_x / 131.0f;
            float gy_dps = gyro_y / 131.0f;
            float gz_dps = gyro_z / 131.0f;

            printf("Accel [g]: X=%.2f Y=%.2f Z=%.2f | Gyro [deg/s]: X=%.1f Y=%.1f Z=%.1f\n",
                   ax_g, ay_g, az_g, gx_dps, gy_dps, gz_dps);
        } else {
            printf("Read error!\n");
        }

        vTaskDelay(pdMS_TO_TICKS(200)); // Sample 5 times per second
    }
}